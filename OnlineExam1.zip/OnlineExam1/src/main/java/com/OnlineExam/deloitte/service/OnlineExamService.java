package com.OnlineExam.deloitte.service;

import java.util.List;

import com.OnlineExam.deloitte.model.Question;

public interface OnlineExamService {

	public void addQuestion(Question question);

}